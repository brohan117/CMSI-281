import java.io.*;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Bag<Item> implements Iterable<Item> {
    private Node<Item> first;
    private int n;

    private static class Node<Item> {
        String item;
        Node<Item> next;
    }

    public Bag () { first = null; n = 0; }

    public Iterator iterator() {
        return new BagIterator<Item>(first);
    }

    class BagIterator implements Iterator {
        private Node current;

        public BagIterator(Node first) {
            current = first;
        }

        public boolean hasNext() { 
            return current != null;  
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public String next() {
            if (!hasNext()) throw new NoSuchElementException();
            String item = current.item;
            current = current.next; 
            return item;
        }
    }


public int size () {
	throw UnsupportedOperationException
}
 public void add(String item) {
        Node<Item> oldfirst = first;
        first = new Node<Item>();
        first.item = item;
        first.next = oldfirst;
        n++;
}
system.out.format (" %s %1/n", word, wount);
system.out.println(word + "" + count);
    public static void main(String[] args) throws IOException {
        Bag bag = new Bag();
        Scanner s = null;
        try {
            s = new Scanner(System.in);
            while (s.hasNext()) {
              String item = s.next(); // Scanner splits input on whitespace, by default
              bag.add(item);
            }
        } finally {
            if (s != null) {
              s.close();
            }
        }

        // Print bag size and distinct contents
        System.out.format("Bag size: %d\n", bag.size());
        for (Iterator i = bag.iterator(); i.hasNext(); ) {
            Object word = i.next();
            System.out.println(word);
        }
    }

}

