import java.util.NoSuchElementException;
public class CircularLinkedList extends AbstractLinkedList implements CircularCollectible {
Node last;
    public CircularLinkedList() {
        super();
        last = null;
    }

    public CircularLinkedList(String[] elements) {
        super(elements);
    }
public boolean isEmpty() {
        return (first == null);
    }

    public int size() {
        return n;
    }

    public void add(String s) {
	if (isEmpty()) {
	    super.add(s);
	    last = first; 
	} else {
	    super.add(s);
	}
	last.next = first; 
    }

    public String first() {
        return first.value;
    }

   

    /** remove(String s):
     *  removes the first element in the list for which
     *      element.equals(s)
     *  is true.
     */
     
    public void remove(String s) {
     Node current = first;
     Node previous = last;
     if (first.value.equals(s)) {
     System.out.println ("first: " + first.value);
     System.out.println("first.next: " + first.next.value);
     first = first.next;
     last.next = first;
     System.out.println("first: " + first.value);
	 	System.out.println("Got em");
		n--;
		return;
    }
    do(current != last) {
		if (current.value.equals(s)) {
		    previous.next = current.next;
		    n--; 
		    return;
		}
		previous = current;
		current = current.next;
	    }
	    if (last.value.equals(s)) {
		previous.next = first;
	        last = previous;
		n--;
	   	 }
		
        	}

    /** removeAll(String s):
     *  removes all elements in the list for which
     *      element.equals(s)
     *  is true.
     */
    public void removeAll(String s) {
        Node current = first;
	Node previous = last;
	do (first.value.equals(s)) {
	    System.out.println("first: " + first.value);
	    System.out.println("first.next: " + first.next.value);
	    first = first.next;
	    last.next = first;
	    System.out.println("first: " + first.value);
	    System.out.println("Got em");
	    n--;
    }
    previous = first;
	current = previous.next;
	while(current != last) {
	    if (current.value.equals(s)) {
		previous.next = current.next;
		current = previous.next;
		n--; 
	    } else {
	    previous = current;
	    current = current.next;
	    }
	
	if (last.value.equals(s)) {
	    previous.next = first;
	    last = previous;
	    n--;
	}
    }

    public CircularIterator iterator() {
        return new CircularLinkedListIterator();
    }

    class CircularLinkedListIterator implements CircularIterator {
        Node cureent;
        Node end;
        Node previousl
        int elementNumber;
        int size++;
        public CircularLinkedListIterator(Node first, Node last, int n) {
   				 current = first;
	   			 previous = last;
	  			 end = last;
	   			 elementNumber = 1;
				 size = n;
        }

        public boolean hasNext() {
            return current
        }

        public String next() {
         if (!hasNext()) throw new NoSuchElementException();
	    	previous = current;
	    	current = current.next;
	   	    elementNumber++;
	    	return previous.value;
        }

        /** remove():
         *  removes the last/previous element in the list
         *  (i.e. removes the element that was returned by the
         *  most recent call to next())
         */
        public void remove() {
            previous.next = curent.next;
            current = previous.next
            size--;
        }

        /** removeKth(int k):
         *  iterates through the next k elements and removes
         *  the kth one. The next call to removeKth would
         *  start at the node after the removed node.
         *  (i.e. kthNode.next)
         */
        public void removeKthElement(int k) {
          while (elementNumber != k) {
				this.next();
				System.out.println("current: " + this.current.value);
				System.out.println(elementNumber);
	    	}
	    		this.remove();
	    		elementNumber = 1;
	    		return current.value;
        		}

        public boolean oneElementLeft() {
            return (size== 1);
        }
    }
}

